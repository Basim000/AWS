
import React from 'react';
import ChatWidget from './components/ChatWidget';

const App = () => {
  return (
    <div>
      <ChatWidget />
    </div>
  );
};

export default App;
