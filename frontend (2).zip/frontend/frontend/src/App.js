
import React from 'react';
import ChatWidget from './src/components/ChatWidget.jsx';

const App = () => {
  return (
    <div>
      <ChatWidget />
    </div>
  );
};

export default App;